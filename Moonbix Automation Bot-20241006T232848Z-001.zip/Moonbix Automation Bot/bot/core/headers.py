from fake_useragent import UserAgent

headers = {
    'Accept': '*/*',
    'Accept-Language': 'en-US',
    "Bnc-Location": "",
    "Bnc-Uuid": "",
    'Clienttype': "web",
    'Content-Type': 'application/json',
    'Csrftoken': '',
    'Device-Info': "",
    "Cache-Control": "no-cache",
    "Pragma": "no-cache",
    "Priority": "u=1, i",
    "Fvideo-Id": "",
    "Fvideo-Token": "",
    "Lang": "en",
    'Origin': 'https://www.binance.com',
    'Referer': 'https://www.binance.com/vi/game/tg/moon-bix',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'User-Agent': UserAgent(os="android").random,
    "X-Growth-Token": ""
}
